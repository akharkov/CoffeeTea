import Vue from 'vue'
import App from './App.vue'







let appMain = new Vue({
  el: '#app', //#appMain
  render: h => h(App)
  
});

